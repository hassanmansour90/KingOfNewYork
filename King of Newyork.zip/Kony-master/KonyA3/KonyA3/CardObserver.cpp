#include "CardObserver.h"
CardObserver::CardObserver()
{
}

CardObserver::~CardObserver()
{
}

