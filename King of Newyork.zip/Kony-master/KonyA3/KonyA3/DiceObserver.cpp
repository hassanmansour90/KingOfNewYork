#include "DiceObserver.h"

DiceObserver::DiceObserver()
{
};


DiceObserver::~DiceObserver()
{
};
