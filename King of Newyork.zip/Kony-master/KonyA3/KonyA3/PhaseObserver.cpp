#include"PhaseObserver.h"
PhaseObserver::PhaseObserver() {
};
void PhaseObserver::setIDPlayer(int idPlayer) {
	id = idPlayer;
}
PhaseObserver::~PhaseObserver() {
};

