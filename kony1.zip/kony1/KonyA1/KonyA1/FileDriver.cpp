/*#include "FileIO.h"
using namespace std;

int main()
{
//NOTE: you will need to uncomment the different sections; if there is an error reading the file the system exits
//cout << "This section tries to open a file that does not exist." << endl << endl;
//FileIO file1("NotARealFile.txt");
//file1.readFile();

//cout << "This opens and reads a file that is not in the right format." << endl << endl;
//FileIO file2("formatErrorFile.txt");
//file2.readFile();

//cout << "This section opens, reads and creates the graph and assigns it to the map." << endl;
//FileIO file3("FileIO.txt");
//file3.readFile();

	//Graph graph(file.regions, file.zones);
	//graph.addEdges();
	//graph.DFS(5);




system("pause");
return 0;

}*/