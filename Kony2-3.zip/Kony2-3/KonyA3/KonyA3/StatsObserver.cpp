#include "StatsObserver.h"
StatsObserver::StatsObserver()
{
}

StatsObserver::~StatsObserver()
{
}

